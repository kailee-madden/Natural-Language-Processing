#!/usr/bin/env python3
import collections
import sys
import string
import chinese_candidates

class Chinese_NGram(object):

    def __init__(self):
        self.counts = {}
        self.total_count = 0
        try:
            self.order = int(sys.argv[1])
        except:
            self.order = 5
        self.queue = collections.deque(maxlen=self.order)
        self.smooth = False

    def train(self, filename):
        """Train the model on a text file."""
        for line in open(filename):
            self.start()
            for token in line:
                if tuple(self.queue) not in self.counts:
                    self.counts[tuple(self.queue)] = collections.Counter()
                    for character in chinese_candidates.candidates(token):
                        self.counts[tuple(self.queue)][character] = 0
                for character in chinese_candidates.candidates(token):
                    if character == token:
                        self.counts[tuple(self.queue)][character] +=1
                self.total_count += 1
                self.read(token)

        self.smoothing()
    
    def smoothing(self):
        if self.smooth == True:
            smooth_count = 0
            length = 0
            for key_1 in list(self.counts.keys()):
                for key_2 in list(self.counts[key_1]):
                    if self.counts[key_1][key_2] > 1:
                        self.counts[key_1][key_2] -= 1
                        smooth_count += 1
                length += len(string.printable)
            for key_1 in list(self.counts.keys()):
                for key_2 in list(self.counts[key_1]):
                    self.counts[key_1][key_2] += smooth_count/length
        else:
            pass
    
    def start(self):
        """Reset the state to the initial state."""
        for i in range(self.order):
            self.queue.append(0)


    def read(self, w):
        """Read in character w, updating the state."""
        self.queue.append(w)

    def prob(self, w):
        """Return the probability of the next character being w given the current state."""
        if self.counts[tuple(self.queue)][w] == 0:
            self.counts[tuple(self.queue)][w] = 1
            self.total_count += 1
        return self.counts[tuple(self.queue)][w]/float(self.total_count)
    