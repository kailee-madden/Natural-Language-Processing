#!/usr/bin/env python3
import string

def check_accuracy(model, file):
    correct = 0
    total = 0
    for line in open(file):
        model.start()
        for w in line.rstrip('\n'):
            probabilities = {}
            for character in string.printable:
                try:
                    probabilities[character] = model.prob(character)
                except:
                    probabilities[character] = 0
            pair_with_max_value = max(probabilities.items(), key=lambda x: x[1])
            key_with_max_value, max_value = pair_with_max_value
            if key_with_max_value == w:
                correct += 1
            total += 1
            model.read(w)
    return float(correct)/total