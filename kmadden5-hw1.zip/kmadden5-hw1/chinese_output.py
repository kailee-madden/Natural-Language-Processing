#!/usr/bin/env python3
import chinese_ngram
from chinese_ngram import Chinese_NGram
import chinese_candidates


model = Chinese_NGram()
model.train("chinese/dev.han")

def character_output(model, filename):
    output = []
    for line in open(filename):
        model.start()
        for token in line.split():
            probabilities = {}
            for character in chinese_candidates.candidates(token):
                try:
                    probabilities[character] = model.prob(character)
                except:
                    probabilities[character] = 0
            pair_with_max_value = max(probabilities.items(), key=lambda x: x[1])
            key_with_max_value, max_value = pair_with_max_value
            output.append(key_with_max_value)
    return output

#print(character_output(model, "chinese/dev.pin"))

def character_accuracy(model, filename1, filename2):
    correct = 0
    total = 0
    with open(filename1) as lines1, open(filename2) as lines2:
        for line1, line2 in zip(lines1, lines2):
            model.start()
            for token1, token2 in zip(line1.split(), line2.split()):
                probabilities = {}
                for character in chinese_candidates.candidates(token1):
                    try:
                        probabilities[character] = model.prob(character)
                    except:
                        probabilities[character] = 0
                pair_with_max_value = max(probabilities.items(), key=lambda x: x[1])
                key_with_max_value, max_value = pair_with_max_value
                if key_with_max_value == token1:
                    correct += 1
                total += 1
                model.read(token2)
    return float(correct)/total

print(character_accuracy(model, "chinese/test.pin", "chinese/test.han"))


