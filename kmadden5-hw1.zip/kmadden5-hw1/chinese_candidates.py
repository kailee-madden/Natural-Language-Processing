#!/usr/bin/env python3

def candidates(token):
    possible_characters = []
    if token == "<space>":
        possible_characters.append(" ")
    else:
        if len(token) == 1:
            possible_characters.append(token)
        for line in open("chinese/charmap"):
            split_line = line.split()
            if token == split_line[1]:
                possible_characters.append(split_line[0])
    return possible_characters