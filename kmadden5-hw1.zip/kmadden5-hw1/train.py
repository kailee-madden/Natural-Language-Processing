#!/usr/bin/env python3
import string
import unigram
from unigram import Unigram
import accuracy

unigram = Unigram()
unigram.train("english/train")
file = "english/dev"

accuracy = accuracy.check_accuracy(unigram, file)
print(accuracy)
            