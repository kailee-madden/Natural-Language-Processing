#!/usr/bin/env python3
import string
import ngram
from ngram import NGram
import accuracy
import unigram
from unigram import Unigram
import accuracy

unigram = Unigram()
unigram.train("english/train")

ngram = NGram()
ngram.train("english/train")
file = "english/test"

accuracy = accuracy.check_accuracy(ngram, file)
print(accuracy)
            