## CSE 40657/60657
# Homework 1

Part 1:

train.py
This file trains the unigram model and prints out the accuracy. This is the file that should be called to run the model and check its accuracy, and is also the file that should be modified to be checking either the dev or test set depending on what is desired.

accuracy.py
This file contains a function called check_accuracy to determine the accuracy of an ngram language model. This function essentially creates a dictionary of all the possible next characters and their associated probabilities, selects the one with the highest probability as the prediction, then compares this actual next character, determining whether the model was correct or incorrect. It then sums these correct predictions and divides by the total number or predictions in order to generate an accuracy score. 


Part 2:

train_ngram.py
This file trains the ngram model and prints out the accuracy. This is the file that should be called to run the model and check its accuracy, and is also the file that should be modified to be checking either the dev or test set depending on what is desired. Depending on what ngram is desired, you can input the number as a command line argument when calling this function, otherwise it will go with a default of 5.

ngram.py
This file contains the Ngram class which has functions to train and predict the probabilities of the next letter based on the desired n-gram length, which is taken as a command line argument.In addition, the file calls the accuracy function from accuracy.py to check the accuracy of the ngram model that was chosen. 
The functions are as follows:
    train: takes in a file, trains the ngram model on this file
    smoothing: does a simple version of discounting smoothing, only runs if self.smooth == True
    start: sets the padding at the beginning of each line
    read: reads in the newest character and adds it to the queue
    prob: calculates the probability that the given character is the next character

accuracy.py
This file contains a function called check_accuracy to determine the accuracy of an ngram language model. This function essentially creates a dictionary of all the possible next characters and their associated probabilities, selects the one with the highest probability as the prediction, then compares this actual next character, determining whether the model was correct or incorrect. It then sums these correct predictions and divides by the total number or predictions in order to generate an accuracy score. 


Part 3:

chinese_output.py
This file contains two functions, one that outputs all the most probable characters into a list based on the given inputs, and one that checks the accuracy of the predicted character by comparing it to the actual character. This is the file that should be called to run the chinese ngram model and to test it. The input files can be modified as desired. In addition, the number of grams is taken as a command line argument and given to the Chinese_NGram class's train function, with the default being a bigram.

chinese_ngram.py
This file follows the same basic format as the ngram.py file, by constructing a class Chinese_NGram which has functions to train and predict the probabilities of different chinese characters based on latin inputs.

chinese_candidates.py
This file contains the function to check for all the possible output candidates as designated in part a of problem 3 and then outputs the possible candidates as a list.